
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css'; 
import Mainroute from './routes';

function App() {
  return (
    <div className="App">

      <Mainroute/>
   
    </div>
  );
}

export default App;
